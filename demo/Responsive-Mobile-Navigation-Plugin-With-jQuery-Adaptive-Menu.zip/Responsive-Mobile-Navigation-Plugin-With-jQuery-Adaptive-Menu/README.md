# jquery.adaptive-menu

## Call

```javascript
$('.wrapmenu').adaptiveMenu({
  query: 768, // media-query for adaptation of the menu
  append: 'body' // append background element
});
```
